import React, { useEffect, useRef } from 'react';
import './contact.css';

function Contact() {
  const contactRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      const contactSection = contactRef.current;
      if (contactSection) {
        const rect = contactSection.getBoundingClientRect();
        const isInView = rect.top < window.innerHeight && rect.bottom >= 0;
        if (isInView) {
          contactSection.querySelector('h1').classList.add('animate');
        } else {
          contactSection.querySelector('h1').classList.remove('animate');
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check immediately in case section is already in view

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="contactus" ref={contactRef}>
      <h1>Ready To explore the<span className="q"> KalkiNi</span> World</h1>
      <div className='btn'>
        <a href="/contact" className="contact-button">Contact Us</a>
      </div>
    </div>
  );
}

export default Contact;
