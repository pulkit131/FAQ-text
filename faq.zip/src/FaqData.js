const faqData = [
    {
      question: "What is your return policy?",
      answer: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"
    },
    {
      question: "How do I track my order?",
      answer: "You can track your order using the tracking link provided in your order confirmation email."
    },
    {
        question: "How do I track my order?",
        answer: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"
      },
      {
        question: "How do I track my order?",
        answer: "You can track your order using the tracking link provided in your order confirmation email."
      },
      {
        question: "How do I track my order?",
        answer: "You can track your order using the tracking link provided in your order confirmation email."
      },
      {
        question: "How do I track my order?",
        answer: "You can track your order using the tracking link provided in your order confirmation email."
      },
      {
        question: "How do I track my order?",
        answer: "You can track your order using the tracking link provided in your order confirmation email."
      },
    // Add more questions and answers as needed
  ];
  
  export default faqData;
  