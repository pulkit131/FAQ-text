// src/App.js

import React, { useState,useEffect } from 'react';
import './App.css';


import FaqSection from './Components/FaqSection';
import Contact from './Components/Contact';
import Footer from './Components/Footer';



function App() {
 

  return (
      <>

       
        <FaqSection />
        <Contact />
        <Footer />
      

      </>
    
  );
}

export default App;
