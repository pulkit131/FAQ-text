import React from 'react';
import './Footer.css';
import tweet from '../images/twitter.png';
import insta from '../images/instagram.png';
import linkedin from '../images/Linkedin.png';
import logo2 from '../images/logo2.jpg';

function Footer() {
    return (
        <footer className="footer">
            <div className="footer-logo">
                <img src={logo2} alt="" />
            </div>
            <div className="footer-content">
                <div className="footer-section links">
                    <ul>
                        <li><a href="/">Legal</a></li>
                        <li><a href="/about">Privacy Policy</a></li>
                        <li><a href="/services">Terms and Conditions</a></li>
                        <li><a href="/contact">About us</a></li>
                    </ul>
                </div>

                <div className="footer-section social">
                    <div className="twitter"><a href="https://twitter.com"><img src={tweet} alt="" /></a></div>
                    <div className="instagram"><a href="https://instagram.com"><img src={insta} alt="" /></a></div>
                    <div className="linkedin"><a href="https://linkedin.com"><img src={linkedin} alt="" /></a></div>
                </div>

                <div className="footer-section links">
                    <ul>
                        <li><a href="/">Navigation</a></li>
                        <li><a href="/about">Home</a></li>
                        <li><a href="/services">Blog</a></li>
                        <li><a href="/contact">Our Team</a></li>
                        <li><a href="/contact">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div className="footer-bottom">
                <p>&copy; 2024 Your Company. All rights reserved.</p>
            </div>
        </footer>
    );
}

export default Footer;
